The participants are encouraged to download following software, suitable for their Operating System.

LaTeX Distribution
------------------

It is a set of  typesetting system which includes many packages to be used by the user. The LaTeX distribution has different name for different operating systems (Linux: TeX Live (cross-platform), Mac OS X: MacTeX and Windows: proTeXt/MikTeX).

Choosing your Copy
------------------

- If you’re new to TeX and LaTeX or just want an easy installation, get a full TeX distribution.

Following are some pointers to TeX distributions recommended.

TeXLive

: It is an easy way to get up and running with LaTeX. It provides a ready-to-run TeXsystem for most types of Unix, Mac OS X, and Windows, and includes all major TeX-related programs. It also includes a complete tree of fonts and macros, with support for many
languages.

Linux

: TeXLive is sufficient.

Mac OS

: [MacTeX](http://www.tug.org/mactex/) is a LaTeX distribution for MacOS X. It is TeXLive with the addition of a native Mac installer and some Mac-specific programs.

Microsoft Windows

: [proTeXt](http://www.tug.org/protext/) is a LaTeX distribution for Microsoft Windows. It is based on [MiKTeX](http://www.miktex.org/). proTeXt guides the MiKTeX installation via a short PDF document. It also adds a few tools on top of MiKTeX

TeXstudio: LaTeX Editor 
-------------------------------

The workshop will be conducted with the use a LaTeX Editor, which is available for all operating systems and is Open-source i.e. [**TeXstudio**](http://www.texstudio.org/).
